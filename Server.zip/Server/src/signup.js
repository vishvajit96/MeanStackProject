const Promise = require("bluebird");  //npm i bluebird
const mysql = require("mysql");       //npm i mysql

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbconfig = require("./dbconfig");

let adduser = async (user) => {
    let conn = mysql.createConnection(dbconfig.dbconfig);
    await conn.connectAsync();

    let sql = "insert into user (username,email,password) values(?,?,?)";

    await conn.queryAsync(sql, [user.username, user.email, user.password]);
    await conn.endAsync();
}

module.exports = { adduser };