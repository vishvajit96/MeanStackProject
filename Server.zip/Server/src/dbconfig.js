const dbconfig = {
    host: "localhost",
    user: "root",
    password: "vishva",
    database: "timetable"
}

module.exports = { dbconfig };
