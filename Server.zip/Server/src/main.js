const express = require("express");
const cors = require("cors");
const app = express();
app.use(express.json());
app.use(cors());

const login = require("./login");
const signup = require("./signup");
const resetpass = require("./resetpass");

app.post("/user", async (req, res) => {
    try {
        await login.getdata(req.body);
        res.json({ operation: true });
    } catch (err) {
        res.json({ operation: false });
    }
});

app.post("/newuser", async (req, res) => {
    try {
        console.log(req.body);
        await signup.adduser(req.body);
        res.json({ operation: true });
    } catch (err) {
        res.json({ operation: false });
    }
});

app.post("/reset", async (req, res) => {
    try {
        console.log(req.body);
        await resetpass.resetpassword(req.body);
        res.json({ operation: true });
    } catch (err) {
        res.json({ operation: false });
    }
});


app.listen(3000);