const Promise = require("bluebird");  //npm i bluebird
const mysql = require("mysql");       //npm i mysql

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbconfig = require("./dbconfig");

let resetpassword = async (user) => {
    let conn = mysql.createConnection(dbconfig.dbconfig);
    await conn.connectAsync();

    let sql = "update user set password=? where email=?";

    let result = await conn.queryAsync(sql, [user.password, user.email]);
    await conn.endAsync();

}

module.exports = { resetpassword };