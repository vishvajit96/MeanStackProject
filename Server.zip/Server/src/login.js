const Promise = require("bluebird");  //npm i bluebird
const mysql = require("mysql");       //npm i mysql

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const dbconfig = require("./dbconfig");


let getdata = async (user) => {
    let conn = mysql.createConnection(dbconfig.dbconfig);
    await conn.connectAsync();

    let sql = "select email,password from user where email=? and password=?";
    let result = await conn.queryAsync(sql, [user.email, user.password]);

    await conn.endAsync();

    if (result.length === 0) {
        throw new Error("Invalid Credentials");
    }
}

module.exports = { getdata };