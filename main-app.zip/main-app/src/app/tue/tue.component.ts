import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tue',
  templateUrl: './tue.component.html',
  styleUrls: ['./tue.component.css']
})
export class TueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
