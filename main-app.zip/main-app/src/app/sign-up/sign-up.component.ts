import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { faGoogle, faFacebook, faTwitter } from '@fortawesome/free-brands-svg-icons';
//import { customValidators } from "@angular/sevices/custom-validation.services";

import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  public fbFormGroup = this.fb.group({
    username: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(25)]],
    email: ['', [Validators.required, Validators.email, Validators.pattern("[^ @]*@[^ @]*")]],
    password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]

  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }

  public faGoogle = faGoogle
  public faFacebook = faFacebook
  public faTwitter = faTwitter

  ngOnInit(): void {
  }
  async SignUpHere() {

    const data = this.fbFormGroup.value;
    //console.log(data);
    const url = 'http://localhost:3000/newuser';

    await this.http.post(url, data).toPromise();

    this.router.navigate(['']);

    this.fbFormGroup.reset('');
  }
}
