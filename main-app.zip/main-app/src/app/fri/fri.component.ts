import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fri',
  templateUrl: './fri.component.html',
  styleUrls: ['./fri.component.css']
})
export class FriComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
