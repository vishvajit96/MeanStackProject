import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wed',
  templateUrl: './wed.component.html',
  styleUrls: ['./wed.component.css']
})
export class WedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
