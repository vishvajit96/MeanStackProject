import { Component, OnInit } from '@angular/core';

//import { faCalendarWeek } from '@fortawesome/free-solid-svg-icons';

import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public fbFormGroup = FormGroup

  // public faCalendarWeek = faCalendarWeek;

  constructor(private fa: FormBuilder, private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
  }

  async save() { }

}
