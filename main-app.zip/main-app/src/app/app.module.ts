import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { HomeComponent } from './home/home.component';
import { MonComponent } from './mon/mon.component';
import { TueComponent } from './tue/tue.component';
import { WedComponent } from './wed/wed.component';
import { ThuComponent } from './thu/thu.component';
import { FriComponent } from './fri/fri.component';
import { SatComponent } from './sat/sat.component';
import { SunComponent } from './sun/sun.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    PagenotfoundComponent,
    SignUpComponent,
    ForgetPasswordComponent,
    HomeComponent,
    MonComponent,
    TueComponent,
    WedComponent,
    ThuComponent,
    FriComponent,
    SatComponent,
    SunComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
