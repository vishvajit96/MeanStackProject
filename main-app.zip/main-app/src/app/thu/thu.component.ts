import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thu',
  templateUrl: './thu.component.html',
  styleUrls: ['./thu.component.css']
})
export class ThuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
