import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { HomeComponent } from './home/home.component';
import { MonComponent } from './mon/mon.component';
import { TueComponent } from './tue/tue.component';
import { WedComponent } from './wed/wed.component';
import { ThuComponent } from './thu/thu.component';
import { FriComponent } from './fri/fri.component';
import { SatComponent } from './sat/sat.component';
import { SunComponent } from './sun/sun.component';
import { sanitizeIdentifier } from '@angular/compiler';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'sign-up', component: SignUpComponent },
  { path: 'forget-password', component: ForgetPasswordComponent },
  { path: 'pagenotfound', component: PagenotfoundComponent },
  {
    path: 'home', component: HomeComponent,
    children: [
      { path: 'mon', component: MonComponent },
      { path: 'tue', component: TueComponent },
      { path: 'wed', component: WedComponent },
      { path: 'thu', component: ThuComponent },
      { path: 'fri', component: FriComponent },
      { path: 'sat', component: SatComponent },
      { path: 'sun', component: SunComponent }
    ]
  },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', component: PagenotfoundComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
