import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  public success = false;
  public alert = false;


  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }

  public fbFormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email, Validators.pattern("[^ @]*@[^ @]*")]],
    password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]
  });

  ngOnInit(): void {
  }

  async resetpassword() {
    //console.log(this.fbFormGroup.value);
    let data = this.fbFormGroup.value;
    let url = "http://localhost:3000/reset";
    let result: any = await this.http.post(url, data).toPromise();


    if (result.operation = true) {
      this.router.navigate(['']);
    } else {
      throw new Error("Invalid credentials");
    }

    this.fbFormGroup.reset('');


  }

}
