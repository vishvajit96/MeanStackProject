import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { faGoogle, faFacebook, faTwitter } from '@fortawesome/free-brands-svg-icons';


import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public faGoogle = faGoogle
  public faFacebook = faFacebook
  public faTwitter = faTwitter

  public credential = false;

  public fbFormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email, Validators.pattern("[^ @]*@[^ @]*")]],
    password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) { }

  ngOnInit(): void { }

  async loginProcessHere() {
    let userdata = this.fbFormGroup.value;
    let url = "http://localhost:3000/user";
    let data: any = await this.http.post(url, userdata).toPromise();

    if (data.operation) {
      sessionStorage.setItem('sid', 'true');
      this.router.navigate(['home']);
    }
    else {
      this.credential = true;
    }

    this.fbFormGroup.reset();
  }

}
