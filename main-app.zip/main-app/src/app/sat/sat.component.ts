import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sat',
  templateUrl: './sat.component.html',
  styleUrls: ['./sat.component.css']
})
export class SatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
